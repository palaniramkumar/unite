{php}
require_once('simplepie.inc');

echo "Evert";
{/php}