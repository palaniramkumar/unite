cron_maintenance.php is a script you can setup to run with cron. We recommend to run it once every day.

Method DeleteTemporaryJobs() deletes all temporary posts older than 2 days. Temporary means that someone started to write a post but never submitted it.