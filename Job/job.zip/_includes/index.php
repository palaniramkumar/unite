<?php
	header('Location: http://www.jobberbase.com/');
	exit;
?>